import os

ChashCommand = input()
if ChashCommand == "거주인구":
    os.system(f"python mattest.py {ChashCommand}")