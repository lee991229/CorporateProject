from Page1Mattest import imgchange

print(imgchange())